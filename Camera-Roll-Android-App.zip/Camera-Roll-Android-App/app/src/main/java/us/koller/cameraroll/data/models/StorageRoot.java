package us.koller.cameraroll.data.models;

public class StorageRoot extends File_POJO {

    public StorageRoot(String path) {
        super(path, false);
    }
}
